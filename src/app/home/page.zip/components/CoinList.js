"use client";
import { useState } from "react";

// Put your SVG icon URLs here (in /public/coins/)
const COIN_ICONS = {
  BTC: "/coins/btc.svg",
  BCH: "/coins/bch.svg",
  ETH: "/coins/eth.svg",
  XRP: "/coins/xrp.svg",
  BNB: "/coins/bnb.svg",
  SOL: "/coins/sol.svg",
  DOGE: "/coins/doge.svg",
  ADA: "/coins/ada.svg",
  PEPE: "/coins/pepe.svg", // Use a placeholder if you don’t have this SVG!
  AVAX: "/coins/avax.svg",
  MATIC: "/coins/matic.svg",
  SHIB: "/coins/shib.svg",
  DOT: "/coins/dot.svg",
  UNI: "/coins/uni.svg",
  TRX: "/coins/trx.svg",
};

const ALL_COINS = [
  { symbol: "BTC", name: "Bitcoin", price: 114651.15, change: 1.47 },
  { symbol: "BCH", name: "Bitcoin Cash", price: 549.3, change: 4.77 },
  { symbol: "ETH", name: "Ethereum", price: 3537.66, change: 3.74 },
  { symbol: "XRP", name: "XRP", price: 3.01, change: 8.33 },
  { symbol: "BNB", name: "BNB", price: 756.4, change: 2.33 },
  { symbol: "SOL", name: "Solana", price: 163.46, change: 2.09 },
  { symbol: "DOGE", name: "Dogecoin", price: 0.20151, change: 3.19 },
  { symbol: "ADA", name: "Cardano", price: 0.421, change: 1.67 },
  { symbol: "PEPE", name: "Pepe", price: 0.00001054, change: 2.73 },
  { symbol: "AVAX", name: "Avalanche", price: 29.11, change: 5.18 },
  { symbol: "MATIC", name: "Polygon", price: 0.82, change: 1.28 },
  { symbol: "SHIB", name: "Shiba Inu", price: 0.000025, change: 1.95 },
  { symbol: "DOT", name: "Polkadot", price: 6.17, change: 2.55 },
  { symbol: "UNI", name: "Uniswap", price: 7.22, change: 2.99 },
  { symbol: "TRX", name: "TRON", price: 0.124, change: 1.34 },
];
// Demo: Your favorites (by symbol)
const WATCHLIST = ["BTC", "ETH", "XRP"];

function sortCoins(coins, sortBy, dir) {
  return [...coins].sort((a, b) =>
    dir === "desc"
      ? b[sortBy] - a[sortBy]
      : a[sortBy] - b[sortBy]
  );
}

export default function CoinList() {
  const [activeTab, setActiveTab] = useState("watchlist");
  const [sortBy, setSortBy] = useState("change");
  const [sortDir, setSortDir] = useState("desc");

  // Select which coins to show
  const coins = activeTab === "watchlist"
    ? ALL_COINS.filter(c => WATCHLIST.includes(c.symbol))
    : ALL_COINS;

  const sortedCoins = sortCoins(coins, sortBy, sortDir);

  const toggleSort = (column) => {
    if (sortBy === column) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else {
      setSortBy(column);
      setSortDir("desc");
    }
  };

  return (
    <div className="bg-[#181a23] rounded-xl p-4 mt-6 max-w-xl mx-auto shadow-lg">
      {/* Tabs */}
      <div className="flex gap-8 mb-4">
                <button
          className={`text-xl font-bold pb-1 border-b-2 transition ${activeTab === "coin" ? "text-white border-blue-500" : "text-gray-400 border-transparent"}`}
          onClick={() => setActiveTab("coin")}
        >
          Coin
        </button>
        <button
          className={`text-xl font-bold pb-1 border-b-2 transition ${activeTab === "watchlist" ? "text-white border-blue-500" : "text-gray-400 border-transparent"}`}
          onClick={() => setActiveTab("watchlist")}
        >
          Watchlist
        </button>

      </div>
      {/* Headers */}
      <div className="flex items-center mb-2 px-1 text-gray-400 font-semibold text-sm">
        <div className="flex-1">Coin</div>
        <button className="w-24 text-right"
          onClick={() => toggleSort("change")}>
          24 hours {sortBy === "change" && (sortDir === "desc" ? "▼" : "▲")}
        </button>
        <button className="w-32 text-right"
          onClick={() => toggleSort("price")}>
          Price {sortBy === "price" && (sortDir === "desc" ? "▼" : "▲")}
        </button>
      </div>
      {/* Coin Rows */}
      {sortedCoins.map((coin) => (
        <div key={coin.symbol} className="flex items-center py-3 border-b border-[#23263a] last:border-b-0">
          <div className="flex-1 flex items-center gap-3">
            <img
              src={COIN_ICONS[coin.symbol] || "/coins/default.svg"}
              alt={coin.symbol}
              className="w-8 h-8 rounded-full bg-[#222] object-contain"
            />
            <div>
              <div className="text-white font-semibold">{coin.name}</div>
              <div className="text-xs text-gray-400">{coin.symbol}</div>
            </div>
          </div>
          <div className={`w-24 text-right font-bold ${coin.change >= 0 ? "text-green-400" : "text-red-400"}`}>
            {coin.change >= 0 ? "+" : ""}{coin.change.toFixed(2)}%
          </div>
          <div className="w-32 text-right text-gray-100 font-bold">${coin.price.toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}