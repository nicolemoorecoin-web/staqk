"use client";
import { useState } from "react";

const WATCHLIST = [
  {
    name: "Bitcoin",
    symbol: "BTC",
    price: 114733,
    change: 1.2,
    icon: "/crypto/btc.svg",
  },
  {
    name: "Ethereum",
    symbol: "ETH",
    price: 3551.73,
    change: 3.5,
    icon: "/crypto/eth.svg",
  },
  {
    name: "Solana",
    symbol: "SOL",
    price: 163.46,
    change: 2.09,
    icon: "/crypto/sol.svg",
  },
];

const COINS = [
  {
    name: "BNB",
    symbol: "BNB",
    price: 754.64,
    change: 1.82,
    icon: "/crypto/bnb.svg",
  },
  {
    name: "Bitcoin",
    symbol: "BTC",
    price: 114733,
    change: 1.2,
    icon: "/crypto/btc.svg",
  },
  {
    name: "Ethereum",
    symbol: "ETH",
    price: 3551.73,
    change: 3.5,
    icon: "/crypto/eth.svg",
  },
  {
    name: "XRP",
    symbol: "XRP",
    price: 3,
    change: 7.06,
    icon: "/crypto/xrp.svg",
  },
  {
    name: "Solana",
    symbol: "SOL",
    price: 163.46,
    change: 2.09,
    icon: "/crypto/sol.svg",
  },
  {
    name: "Pepe",
    symbol: "PEPE",
    price: 0.00001054,
    change: 2.73,
    icon: "/crypto/pepe.png", // use your own icon!
  },
  {
    name: "Pudgy Penguins",
    symbol: "PENGU",
    price: 0.036301,
    change: 9.65,
    icon: "/crypto/penguin.png",
  },
  {
    name: "Ethena",
    symbol: "ENA",
    price: 0.6121,
    change: 16.08,
    icon: "/crypto/ethena.png",
  },
  {
    name: "Dogecoin",
    symbol: "DOGE",
    price: 0.20151,
    change: 3.19,
    icon: "/crypto/doge.svg",
  },
  {
    name: "Litecoin",
    symbol: "LTC",
    price: 87.23,
    change: 2.45,
    icon: "/crypto/ltc.svg",
  },
  // ... add more as you like
];

export default function Watchlist() {
  const [tab, setTab] = useState("watchlist");

  const list = tab === "watchlist" ? WATCHLIST : COINS;

  return (
    <section className="bg-[#222531] rounded-2xl shadow-lg px-3 py-6 mt-7 w-full max-w-lg mx-auto">
      {/* Tabs */}
      <div className="flex gap-5 mb-3 text-xl font-semibold">
        <button
          className={`${
            tab === "watchlist"
              ? "text-white font-bold"
              : "text-gray-400 font-semibold"
          } focus:outline-none`}
          onClick={() => setTab("watchlist")}
        >
          Watchlist
        </button>
        <button
          className={`${
            tab === "coin"
              ? "text-white font-bold"
              : "text-gray-400 font-semibold"
          } focus:outline-none`}
          onClick={() => setTab("coin")}
        >
          Coin
        </button>
      </div>

      {/* Table Header */}
      <div className="flex items-center gap-4 mb-3 text-xs text-gray-400 px-2">
        <span className="bg-[#313446] px-3 py-1 rounded-lg font-bold">Hot</span>
        <span className="ml-2">Market Cap</span>
        <span className="ml-4">Price</span>
        <span className="ml-auto">24h Change</span>
      </div>

      {/* List */}
      <div className="flex flex-col gap-4">
        {list.map((coin) => (
          <div key={coin.symbol} className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
              <img
                src={coin.icon}
                alt={coin.symbol}
                className="w-9 h-9 rounded-full"
              />
              <div>
                <div className="text-white font-medium text-lg">{coin.name}</div>
                <div className="text-gray-400 text-xs font-semibold">
                  {coin.symbol}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div
                className={`font-bold text-base ${
                  coin.change > 0 ? "text-green-400" : "text-red-400"
                }`}
              >
                {coin.change > 0 ? "+" : ""}
                {coin.change.toFixed(2)}%
              </div>
              <div className="text-gray-300 font-medium text-sm">
                $
                {typeof coin.price === "number"
                  ? coin.price.toLocaleString()
                  : coin.price}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
