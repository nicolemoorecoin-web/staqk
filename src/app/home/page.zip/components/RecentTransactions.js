// src/components/RecentTransactions.js
import React from "react";

// You can move this data to props later if you want!
const recentTx = [
  {
    id: 1,
    iconBg: "bg-orange-100",
    icon: (
      <svg width="32" height="32" fill="none" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="12" fill="#fbbf24" opacity="0.18"/>
        <path d="M7 15.5v-6a2 2 0 0 1 2-2h6v8.5a1.5 1.5 0 0 1-1.5 1.5H8.5A1.5 1.5 0 0 1 7 17V15.5Z" stroke="#f59e42" strokeWidth="1.5" fill="none"/>
        <path d="M10 12h4M12 14v-2" stroke="#f59e42" strokeWidth="1.3" strokeLinecap="round"/>
      </svg>
    ),
    title: "USDT Deposit",
    datetime: "Aug 2nd, 19:54:05",
    amount: "+$350.00",
    status: "Successful",
    statusColor: "bg-green-100 text-green-600",
    amountColor: "text-white"
  },
  {
    id: 2,
    iconBg: "bg-green-100",
    icon: (
      <svg width="32" height="32" fill="none" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="12" fill="#34d399" opacity="0.18"/>
        <rect x="7" y="10" width="10" height="6" rx="1" stroke="#34d399" strokeWidth="1.5" fill="none"/>
        <rect x="9" y="8" width="6" height="2" rx="1" stroke="#34d399" strokeWidth="1.2" fill="none"/>
      </svg>
    ),
    title: "BTC Transfer to bc1qxy2kgd...3kwlh",
    datetime: "Aug 2nd, 19:53:52",
    amount: "-$3,500.00",
    status: "Successful",
    statusColor: "bg-green-100 text-green-600",
    amountColor: "text-white"
  }
];

export default function RecentTransactions() {
  return (
    <section className="w-full px-0 pt-5 pb-2">
      <div className="bg-[#1b2030] rounded-2xl shadow-md px-4 py-3 mx-0 flex flex-col gap-3">
        {recentTx.map((tx) => (
          <div key={tx.id} className="flex items-center gap-3">
            {/* Icon */}
            <span className={`w-12 h-12 flex items-center justify-center rounded-full ${tx.iconBg}`}>{tx.icon}</span>
            {/* Details */}
            <div className="flex-1 min-w-0">
              <div className="text-[1.06rem] font-medium truncate">{tx.title}</div>
              <div className="text-gray-400 text-[.97rem] font-normal">{tx.datetime}</div>
            </div>
            {/* Amount & status */}
            <div className="flex flex-col items-end min-w-[100px]">
              <span className={`font-bold text-lg ${tx.amountColor}`}>{tx.amount}</span>
              <span className={`mt-1 text-xs font-semibold px-2 py-1 rounded-lg ${tx.statusColor}`}>{tx.status}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}