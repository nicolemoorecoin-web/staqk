"use client";
import { HiUserCircle } from "react-icons/hi";
import { FiPlusCircle, FiMinusCircle, FiArrowRightCircle } from "react-icons/fi";
import RecentTransactions from './components/RecentTransactions';
import PromoSlider from './components/PromoSlider';
import CoinList from "./components/CoinList";
import TopStocksChart from './components/TopStocksChart';

function ActionCard({ icon, label }) {
  return (
    <button className="flex flex-col items-center justify-center bg-[#222842] rounded-xl shadow-md py-3 px-6 flex-1 mx-1 hover:bg-blue-900/60 transition-all">
      <div className="mb-1 text-blue-400">{icon}</div>
      <span className="text-white text-sm font-medium">{label}</span>
    </button>
  );
}

export default function HomePage() {
  return (
    <main className="bg-[#10141c] min-h-screen">
      <div className="w-full min-h-screen flex flex-col items-stretch justify-start">
        {/* Parent Card */}
        <div className="w-full bg-[#1b2030] rounded-none sm:rounded-2xl shadow-2xl p-0 sm:p-8 pt-7 flex flex-col items-stretch gap-4">
          
          {/* Hi, Henry */}
          <div className="flex items-center gap-3 px-6 pt-2 pb-4">
            <HiUserCircle className="w-10 h-10 text-blue-400" />
            <span className="text-white text-lg font-normal">
              Hi, <span className="font-bold">Henry</span>
            </span>
          </div>
          
          {/* ATM Card */}
          <div className="w-full px-4 pb-4">
            <div className="w-full rounded-xl bg-gradient-to-tr from-blue-700 to-blue-400 shadow-lg px-6 py-6 flex flex-col gap-1">
              <div className="flex justify-between items-center mb-3">
                <span className="text-white text-lg font-semibold opacity-90">Available Balance</span>
                <button className="bg-black/40 text-white text-xs font-bold px-3 py-1 rounded-lg shadow hover:bg-opacity-70 transition">Top Up</button>
              </div>
              <div className="text-3xl sm:text-4xl text-white font-extrabold tracking-wide mb-4">$12,500</div>
              <div className="flex justify-between mt-2">
                <div>
                  <span className="text-xs text-white/80 block">Income</span>
                  <span className="text-green-400 font-bold">+ $2,450</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-white/80 block">Expenses</span>
                  <span className="text-red-400 font-bold">- $920</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 px-4 pb-6 pt-2">
            <ActionCard icon={<FiPlusCircle size={28} />} label="Deposit" />
            <ActionCard icon={<FiMinusCircle size={28} />} label="Withdraw" />
            <ActionCard icon={<FiArrowRightCircle size={28} />} label="Transfer" />
          </div>
           <RecentTransactions />
           <PromoSlider />
           <CoinList/>
           <TopStocksChart/>
           
        </div>
      </div>
    </main>
  );
}